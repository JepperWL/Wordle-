namespace Wordle_Beta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List <string> listKata = new List<string>();
        string kataRandom = "";
        private void Form1_Load(object sender, EventArgs e)
        {
            panel_input.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button btnUser = sender as Button;
            string tebakanUser = btnUser.Text.ToString();
            char fixUser = Convert.ToChar(tebakanUser);
            int posisiHuruf = 0;
          
            
                for (int i = 0; i < 5; i++)
                {
                    if (kataRandom[i] == fixUser)
                    {
                        posisiHuruf = i;
                        if (posisiHuruf == 0)
                        {
                            lbl_1.Text = fixUser.ToString();
                        }
                        if (posisiHuruf == 1)
                        {
                            lbl2.Text = fixUser.ToString();
                        }
                        if (posisiHuruf == 2)
                        {
                            lbl3.Text = fixUser.ToString();
                        }
                        if (posisiHuruf == 3)
                        {
                            lbl4.Text = fixUser.ToString();
                        }
                        if (posisiHuruf == 4)
                        {
                            lbl5.Text = fixUser.ToString();
                        }
                    }
                }
            string cekMenang = lbl_1.Text + lbl2.Text + lbl3.Text + lbl4.Text + lbl5.Text;
            if (kataRandom == cekMenang)
            {
                MessageBox.Show("Selamat Anda Menang");
            }
        }

        private void btn_main_Click(object sender, EventArgs e)
        {
            if (tb_word1.Text == "" || tb_word2.Text == "" || tb_word3.Text == "" || tb_word4.Text == "" || tb_word5.Text == "")
            {
                MessageBox.Show("Gaboleh Kosong yaa");
                listKata.Clear();
            }
            else if (tb_word1.Text.Length != 5 || tb_word2.Text.Length != 5 || tb_word3.Text.Length != 5 || tb_word4.Text.Length != 5 || tb_word5.Text.Length != 5)
            {
                MessageBox.Show("Harus 5 yaa");
                listKata.Clear();
            }
            else
            {
                listKata.Add(tb_word1.Text.ToUpper());
                listKata.Add(tb_word2.Text.ToUpper());
                listKata.Add(tb_word3.Text.ToUpper());
                listKata.Add(tb_word4.Text.ToUpper());
                listKata.Add(tb_word5.Text.ToUpper());

                Random rnd = new Random();
                int index = rnd.Next(0, 5);
                kataRandom = listKata[index];
                panel_input.Visible = false;
                panel_tebak.Visible = true;
            }  
        }

        private void btn_answer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Jawabannya Adalah : " + kataRandom);
        }
    }
}
